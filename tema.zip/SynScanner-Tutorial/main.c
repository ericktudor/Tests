
#include <stdio.h>       // printf, puts
#include <getopt.h>      // getopt_long
#include <string.h>      // memset
#include <stdlib.h>      // malloc, atoi
#include <unistd.h>      // close syscall
#include <ctype.h>       // isdigit
#include <sys/socket.h>  // socket APIs
#include <arpa/inet.h>   // inet_ntoa
#include <netinet/tcp.h> // TCP header
#include <netinet/ip.h>  // IP header
#include <netdb.h>       // gethostbyname
#include <time.h>        // for localtime
#include "src/scanner.h"
#include "src/udp.h"
#include "src/icmp.h"
#define MAX_PORTBUF_SIZE 1024
#define BUF_SIZE 65536
#define DNS_SERVER "1.1.1.1"
#define DNS_SERVER_PORT 53
#define VERSION "0.0.1"
#define PORT_NO 0
// Private methods
static void get_client_ip(char *ip_addr);
pthread_mutex_t lock1 = PTHREAD_MUTEX_INITIALIZER;
// Performs a DNS lookup
/*
char *dns_lookup(char *addr_host, struct sockaddr_in *addr_con)
{
    printf("\nResolving DNS..\n");
    struct hostent *host_entity;
    char *ip = (char *)malloc(NI_MAXHOST * sizeof(char));
    // int i;

    if ((host_entity = gethostbyname(addr_host)) == NULL)
    {
        // No ip found for hostname
        return NULL;
    }

    // filling up address structure
    strcpy(ip, inet_ntoa(*(struct in_addr *)host_entity->h_addr));

    (*addr_con).sin_family = host_entity->h_addrtype;
    (*addr_con).sin_port = htons(PORT_NO);
    (*addr_con).sin_addr.s_addr = *(long *)host_entity->h_addr;

    return ip;
}
*/
struct arg_struct
{
    int start_port;
    int last_port;
    struct in_addr server_ip;
    int counter;
};

void *scanthread(void *arguments)
{
    struct arg_struct *args = arguments;
    int start_port = args->start_port;
    int last_port = args->last_port;
    int sock_fd = 0; // Raw socket file descriptor
    struct in_addr server_ip = args->server_ip;
    char ip_addr[MAX_PORTBUF_SIZE]; // Local IP address

    // Open raw socket
    sock_fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    if (sock_fd < 0)
    {
        perror("Unable to create socket");
        return NULL;
    }

    // Prepare TCP/IP Header
    char datagram[DATAGRAM_BUF_SIZE];
    struct iphdr *ip_head = (struct iphdr *)datagram;                          // IP header
    struct tcphdr *tcp_head = (struct tcphdr *)(datagram + sizeof(struct ip)); // TCP header
    get_client_ip(ip_addr);
    setup_datagram(datagram, server_ip, ip_addr, ip_head, tcp_head);
    tcp_head->source = htons(46300 + args->counter);
    // tcp_head->source=htons(46300+args->counter);

    // For each port, set header's parameters and send SYN packet to host
    for (int current_port = start_port; current_port <= last_port; current_port++)
    {
        if (scan_port(sock_fd, datagram, server_ip, ip_addr, tcp_head, current_port) != 0)
        {
            perror("Unable to send SYN packet");
            return NULL;
        }
    }
    // Finally, close raw socket
    close(sock_fd);
    return NULL;
}
int main(int argc, char *argv[])
{

    int choice = 0;
    printf("ICMP Scan:1\nSYN Scan:2\n");
    scanf("%d", &choice);
    if (choice == 1)
    {

        printf("------");
        pthread_t thread_id[4];
        // char vector[3][100]; // = {"google.com", "youtube.com", "wiki.mta.ro"}; // pentru wiki da ca e up???????????????

        if (argv[1] == NULL)
        {
            printf("Format is : sudo ./sps <filename>\n");
            return 0;
        }
        printf("%s", argv[1]);
        fflush(stderr);
        fflush(stdout);

        FILE *f;
        f = fopen(argv[1], "r");
        printf("------");
        fflush(stderr);
        fflush(stdout);
        if (f == NULL)
        {

            printf("error open\n");
            fflush(stderr);
            fflush(stdout);
        }
        int nr_lines = 0;
        char line[256];

        while (fgets(line, sizeof(line), f))
        {
            // Increment the line count
            nr_lines++;
        }
        printf("%d", nr_lines);
        fflush(stderr);
        fflush(stdout);

        fclose(f);

        f = fopen(argv[1], "r");

        char buffer[50];
        char **host = (char **)malloc(10 * sizeof(char *));
        for (int i = 0; i < nr_lines; i++)
        {
            host[i] = (char *)malloc(sizeof(char));
        }
        int x = 0;
        while (fgets(buffer, 50, f) != NULL)
        {
            char *p;
            p = strtok(buffer, "\n");
            // printf("%s\n",p);
            strcpy(host[x], p);
            // printf("%s\t",host[nr_lines]);
            x++;
        }
        printf("%d\n", nr_lines);
        fflush(stderr);
        fflush(stdout);

        for (int i = 0; i < nr_lines; i++)
        {
            printf("%s\t", host[i]);
        }
        fflush(stderr);
        fflush(stdout);

        struct aux args[4];
        int hostnr = nr_lines / 4;
        // implementare threads
        for (int i = 0; i < nr_lines; i++)
        {
            char *ip_addr, *reverse_hostname;
            struct sockaddr_in addr_con;

            ip_addr = dns_lookup(host[i], &addr_con);
            if (ip_addr == NULL)
            {
                printf("\nDNS lookup failed! Could not resolve hostname %s!\n\n", host[i]);
                fflush(stderr);
                fflush(stdout);
                exit(-1);
            }

            reverse_hostname = reverse_dns_lookup(ip_addr);

            // printf("\nTrying to connect to '%s' IP: %s\n", host[i], ip_addr);
            // printf("\nReverse Lookup domain: %s\n", reverse_hostname);

            // struct aux par;
            // par.ping_addr = &addr_con;
            // par.ping_dom = (char *)malloc(strlen(host[i]) * sizeof(char));
            // strcpy(par.ping_dom, host[i]);
            // par.ping_ip = (char *)malloc(strlen(ip_addr) * sizeof(char));
            // strcpy(par.ping_ip, ip_addr);
            // par.rev_host = (char *)malloc(strlen(reverse_hostname) * sizeof(char));
            // strcpy(par.rev_host, reverse_hostname);

            args[i].ping_addr = &addr_con;
            args[i].ping_dom = (char *)malloc(strlen(host[i]) * sizeof(char));
            strcpy(args[i].ping_dom, host[i]);
            args[i].ping_ip = (char *)malloc(strlen(ip_addr) * sizeof(char));
            strcpy(args[i].ping_ip, ip_addr);
            args[i].rev_host = (char *)malloc(strlen(reverse_hostname) * sizeof(char));
            strcpy(args[i].rev_host, reverse_hostname);
            args[i].start = hostnr * i;
            args[i].end = hostnr * (i + 1);

            // strcpy(par.ping_dom,"google.com");
            // strcpy(par.ping_ip,ip_addr);
            // par.rev_host=reverse_hostname;

            pthread_mutex_lock(&lock1);

            pthread_create(&thread_id[i], NULL, (void *)send_ping, &args[i]);

            pthread_mutex_unlock(&lock1);
            // pthread_join(thread_id[i], NULL);

            free(ip_addr);
            free(reverse_hostname);

            printf("----------------------------------------\n");
        }

        for (int i = 0; i < nr_lines; i++)
        {
            pthread_join(thread_id[i], NULL);
        }

        for (int i = 0; i < 4; i++)
        {
            free(args[i].rev_host);
            free(args[i].ping_dom);
            free(args[i].ping_ip);
        }

        for (int i = 0; i < nr_lines; i++)
        {
            free(host[i]);
        }
        free(host);

        pthread_mutex_destroy(&lock1);
        fclose(f);
        pthread_exit(NULL);

        return 0;
    }
    else if (choice == 2)
    {
        char myip[32];
        get_client_ip(myip);
        // printf("%s\n",myip);
        // udp_scan(myip);
        struct in_addr server_ip;
        char host[15]; // Target host
        printf("IP Address Target:\n");
        scanf("%s", host);
        char temp[10];
        int start_port;
        int last_port;
        printf("Starting Port:\n");
        scanf("%s", temp);
        start_port = atoi(temp);
        printf("Last Port:\n");
        scanf("%s", temp);
        last_port = atoi(temp);
        pthread_t some_thread[4];
        struct arg_struct args[4];
        server_ip.s_addr = inet_addr(host);
        int port_div = (last_port - start_port) / 4;
        for (int thread_counter = 0; thread_counter <= 3; thread_counter++)
        {
            args[thread_counter].start_port = start_port + port_div * thread_counter;
            args[thread_counter].last_port = start_port + port_div * (thread_counter + 1);
            args[thread_counter].server_ip = server_ip;
            args[thread_counter].counter = thread_counter;
            if (pthread_create(&some_thread[thread_counter], NULL, &scanthread, (void *)&args[thread_counter]) != 0)
            {
                printf("Uh-oh!\n");
                return -1;
            };
        }
        for (int j = 0; j <= 3; j++)
        {
            pthread_join(some_thread[j], NULL);
        }

        return 0;
    }
}

// Retrieve IP address of client
void get_client_ip(char *ip_addr)
{
    // To get local ip address, we can send a UDP packet
    // to a DNS server, wait for its reply and then
    // read the "sin_addr" field from the header of
    // the packet.
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 1)
    {
        perror("Unable to create UDP socket");
        exit(1);
    }

    struct sockaddr_in ip_client, name;
    memset(&ip_client, 0, sizeof(ip_client));

    // Configure the header
    ip_client.sin_addr.s_addr = inet_addr(DNS_SERVER);
    ip_client.sin_port = htons(DNS_SERVER_PORT);
    ip_client.sin_family = AF_INET;

    // Establish a new connection
    int res = connect(sock, (struct sockaddr *)&ip_client, sizeof(ip_client));
    if (res < 0)
    {
        perror("Unable to connect to remote host");
        exit(1);
    }

    socklen_t name_len = sizeof(name);
    res = getsockname(sock, (struct sockaddr *)&name, &name_len);
    if (inet_ntop(AF_INET, &name.sin_addr, ip_addr, INET_ADDRSTRLEN) == NULL)
    {
        perror("Unable to retrieve IP address of the client");
        exit(1);
    }

    // Close socket
    close(sock);
}
