#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <arpa/inet.h>

#define MAX_PORTS 65535
#define TIMEOUT 5 // in seconds

int main(int argc, char *argv[]) {
  if (argc < 2) {
    fprintf(stderr, "Usage: %s <ip address>\n", argv[0]);
    return 1;
  }

  char *target_ip = argv[1];

  int sockfd;
  if ((sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) < 0) {
    perror("socket");
    return 1;
  }

  // Set IP_HDRINCL so we can specify our own IP header
  int hdrincl = 1;
  if (setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &hdrincl, sizeof(hdrincl)) < 0) {
    perror("setsockopt");
    return 1;
  }

  // Set IP_RECVTTL so we can see the time to live of the response packet
  int ttl = 1;
  if (setsockopt(sockfd, IPPROTO_IP, IP_RECVTTL, &ttl, sizeof(ttl)) < 0) {
    perror("setsockopt");
    return 1;
  }

  // Allocate memory for the IP header and UDP header
  void *packet = malloc(sizeof(struct ip) + sizeof(struct udphdr));
  if (!packet) {
    perror("malloc");
    return 1;
  }

  struct ip *ip_hdr = packet;
  struct udphdr *udp_hdr = packet + sizeof(struct ip);

  // Set up the IP header
  ip_hdr->ip_v = 4;
  ip_hdr->ip_hl = 5;
  ip_hdr->ip_tos = 0;
  ip_hdr->ip_len = htons(sizeof(struct ip) + sizeof(struct udphdr));
  ip_hdr->ip_id = 0;
  ip_hdr->ip_off = 0;
  ip_hdr->ip_ttl = 255;
  ip_hdr->ip_p = IPPROTO_UDP;
  ip_hdr->ip_sum = 0;
  ip_hdr->ip_src.s_addr = inet_addr("10.0.2.15"); // Use 0.0.0.0 for the source address
  ip_hdr->ip_dst.s_addr = inet_addr(target_ip);

  // Set up the UDP header
  udp_hdr->source = htons(12345); // Use an arbitrary
    for (int i = 120; i < MAX_PORTS; i++) {
    udp_hdr->dest = htons(i);
    udp_hdr->len = htons(sizeof(struct udphdr));
    udp_hdr->check = 0;

    struct sockaddr_in target_addr;
    memset(&target_addr, 0, sizeof(target_addr));
    target_addr.sin_family = AF_INET;
    target_addr.sin_addr.s_addr = ip_hdr->ip_dst.s_addr;

    // Send the packet
    if (sendto(sockfd, packet, sizeof(struct ip) + sizeof(struct udphdr), 0, (struct sockaddr *) &target_addr, sizeof(target_addr)) < 0) {
      perror("sendto");
      return 1;
    }

    // Set up the file descriptor set for the call to select()
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(sockfd, &fds);

    struct timeval tv;
    tv.tv_sec = TIMEOUT;
    tv.tv_usec = 0;

    if (select(sockfd + 1, &fds, NULL, NULL, &tv) > 0) {
      // Receive the response
      struct sockaddr_in response_addr;
      socklen_t response_addr_len = sizeof(response_addr);
      char response_buf[2048];
      if (recvfrom(sockfd, response_buf, sizeof(response_buf), 0, (struct sockaddr *) &response_addr, &response_addr_len) < 0) {
        perror("recvfrom");
        return 1;
      }

      struct ip *response_ip_hdr = (struct ip *) response_buf;
      struct udphdr *response_udp_hdr = (struct udphdr *) (response_buf + sizeof(struct ip));

      // Check the time to live of the response packet
      if (response_ip_hdr->ip_ttl > 1) {
        printf("Port %d: open\n", i);
      } else {
        printf("Port %d: closed\n", i);
      }
    } else {
      printf("Port %d: closed\n", i);
    }
  }

  close(sockfd);
  free(packet);

  return 0;
}
