#include "sniffer.h"
#include <errno.h>
static void sniff_network(struct in_addr server_ip, const unsigned int port,int source_port);
static void print_result(unsigned int port, enum status st);
void decode_packet(unsigned char *buf){

    // Print IP header first
    struct iphdr *ip_head = (struct iphdr*)buf;
    struct sockaddr_in ip_source, ip_dest;
    unsigned short ip_head_len = ip_head->ihl*4;

    memset(&ip_source, 0, sizeof(ip_source));
    memset(&ip_dest, 0, sizeof(ip_dest));
    ip_source.sin_addr.s_addr = ip_head->saddr; // Get source IP address
    ip_dest.sin_addr.s_addr = ip_head->daddr; // Get destination IP address
    struct tcphdr *tcp_head = (struct tcphdr*)(buf + ip_head_len);
   // if(tcp_head->dest==port){
    printf("\n\n################### TCP PACKET ###################");
    printf("\nIP header\n");
    printf("   Version              : %d\n", (unsigned int)ip_head->version);
    printf("   HELEN                : %d Bytes\n", ((unsigned int)(ip_head->ihl))*4);
    printf("   TOS                  : %d\n", (unsigned int)ip_head->tos);
    printf("   Total length         : %d Bytes\n", ntohs(ip_head->tot_len));
    printf("   Identification       : %d\n", ntohs(ip_head->id));
    printf("   Time-To-Live         : %d\n", (unsigned int)(ip_head->ttl));
    printf("   Protocol             : %d\n", (unsigned int)(ip_head->protocol));
    printf("   Checsum              : %d\n", (unsigned int)(ip_head->check));
    printf("   Source IP            : %s\n", inet_ntoa(ip_source.sin_addr));
    printf("   Destination IP       : %s\n", inet_ntoa(ip_dest.sin_addr));

    // Print TCP header


    printf( "\nTCP header\n");
    printf( "   Source port          : %u\n", ntohs(tcp_head->source));
    printf( "   Destination port     : %u\n", ntohs(tcp_head->dest));
    printf( "   Sequence number      : %u\n", ntohl(tcp_head->seq));
    printf( "   Ack number           : %u\n", ntohl(tcp_head->ack_seq));
    printf( "   Header length        : %u Bytes\n", (unsigned int)tcp_head->doff*4);
    printf( "   UFLAG                : %u\n", (unsigned int)tcp_head->urg);
    printf( "   AFLAG                : %u\n", (unsigned int)tcp_head->ack);
    printf( "   PFLAG                : %u\n", (unsigned int)tcp_head->psh);
    printf( "   RFLAG                : %u\n", (unsigned int)tcp_head->rst);
    printf( "   SFLAG                : %u\n", (unsigned int)tcp_head->syn);
    printf( "   FFLAG                : %u\n", (unsigned int)tcp_head->fin);
    printf( "   Window               : %u\n", htons(tcp_head->window));
    printf( "   Checksum             : %u\n", htons(tcp_head->check));
    printf( "   urgent Pointer       : %u\n", htons(tcp_head->urg_ptr));
    printf( "\n\t\t\t ..::: DATA :::..\n");
 //   }
}
void *sniffer_thread_callback(void *ptr) {
    struct target_header *th = ptr;

    sniff_network(th->target_ip, th->target_port,th->source_port);

    return (void*)NULL;
}

void sniff_network(struct in_addr server_ip, const unsigned int port,int source_port) {
    int sock_raw;
    int saddr_size, data_size;
    struct sockaddr saddr;
    unsigned char *buf = (unsigned char*)malloc(BUF_SIZE);

    // Create new raw socket
    sock_raw = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if(sock_raw < 0) {
        perror("Unable to create socket");
        exit(1);
    }

    saddr_size = sizeof(saddr);
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 100000;
    setsockopt(sock_raw, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof tv);
    // Start receiving packets
    data_size = recvfrom(sock_raw, buf, BUF_SIZE, 0, (struct sockaddr*)&saddr, (socklen_t*)&saddr_size);
     if(errno==EWOULDBLOCK||errno==EAGAIN){
        //printf("%d didnt respond\n",port);
        errno=0;
        free(buf);
        return;

    }
    if(data_size < 0) {
        perror("Unable to receive packets");
        exit(1);
    }
    //decode_packet(buf);

    // Process data
    struct iphdr *ip_head = (struct iphdr*)buf;
    struct sockaddr_in source;
    unsigned short ip_head_len = ip_head->ihl*4;
    struct tcphdr *tcp_head = (struct tcphdr*)(buf + ip_head_len);
    memset(&source, 0, sizeof(source));
    source.sin_addr.s_addr = ip_head->saddr;

    if(ip_head->protocol == IPPROTO_TCP) {
        // Now check whether it's a SYN-ACK packet or not
        if(tcp_head->syn == 1 && tcp_head->ack == 1 && source.sin_addr.s_addr == server_ip.s_addr && tcp_head->dest==source_port){
            print_result(port, OPEN);
            free(buf);
            return;
        }
        else if(tcp_head->rst==1&& tcp_head->dest==source_port){
            print_result(port, CLOSED);
            free(buf);
            return;
        }
        else{
            sniff_network(server_ip,port,source_port);
            close(sock_raw);
            }
    }
    free(buf);
}

// Print the scan result just like Nmap
void print_result(unsigned int port, enum status st) {
    printf("%d/tcp\t\t%s\n", port, (st == OPEN ? "open" : "closed"));
}
